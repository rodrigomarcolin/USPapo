from django.db import models
from django.contrib.auth.models import User
from pygments.lexers import get_lexer_by_name
from pygments.formatters.html import HtmlFormatter
from pygments import highlight
from django.contrib.auth.models import User

#class Profile(models.Model):
 #   user = models.OneToOneField(User, on_delete=models.CASCADE)
 #   image = models.ImageField(default='padrão.png', upload_to='perfil_fotos')
 #   curso = models.CharField(max_length=100, null=True)
 #   campus = models.CharField(max_length=100, default='USP')
 #   exp_academicas = models.CharField(max_length=512, null=True)
 #   int_academicos = models.CharField(max_length=512, null=True)
 #   email = models.CharField(max_length=256)

   # def __str__(self):
   #     return f'{self.user.username} Profile'

class Evento(models.Model):
    titulo = models.CharField(max_length=128)
    descricao = models.CharField(max_length = 512, blank=True)
    categoria = models.IntegerField()
    criado_data = models.DateField(auto_now_add=True)
    criado_hora = models.TimeField(auto_now_add=True)
    modificado_data = models.DateField(auto_now=True)
    modificado_hora = models.TimeField(auto_now=True)
    data = models.DateField()
    hora = models.TimeField()
    owner = models.ForeignKey(User, related_name='eventos', on_delete=models.CASCADE)
    def __str__(self):
        return self.titulo
